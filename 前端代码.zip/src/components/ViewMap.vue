<template>
  <div class="ViewMap">
    <h2>My Map</h2>
  </div>
</template>

<script>
export default {
  name: 'ViewMap',

  data() {
    return {
      map: ''
    }
  },
  mounted() {}
}
</script>



<style scoped>
</style>
