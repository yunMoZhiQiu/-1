<template>
  <div class="hello">
    <el-container>
      <el-header class="fontbig">学生信息管理系统</el-header>
      <el-main style="text-align: right; font-size: 12px">
        <span class="fontme">欢迎：{{ Loginform.name }}</span>

        <el-dropdown style="margin-left: 10px">
          <i class="el-icon-setting" style="margin-right: 15px"></i>
          <el-dropdown-menu slot="dropdown">
            <el-button type="" size="mini" @click="Login"><el-dropdown-item>登录</el-dropdown-item></el-button>
            <el-button type="" size="mini" @click="Leave"><el-dropdown-item>退出</el-dropdown-item></el-button>
          </el-dropdown-menu>
        </el-dropdown>
      </el-main>
      <el-main>
        <el-tabs :tab-position="tabPosition" style="height: 800px" type="border-card">
          <el-tab-pane>
            <span slot="label"><i class="el-icon-user"></i>学生基本信息</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px">
                <el-form
                  :model="StuInfoForm"
                  ref="StuInfoForm"
                  label-width="60px"
                  size="mini"
                  class="demo-ruleForm"
                  :inline="true"
                  id="changeposition"
                  :rules="rules"
                >
                  <el-form-item label="学号" prop="stuno">
                    <el-input v-model="StuInfoForm.stuno" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item>
                    <el-button type="primary" @click="getsutinfoBystuno(StuInfoForm.stuno)">提交</el-button>
                    <el-button @click="getStuInfoAll()">全部</el-button>
                    <el-button @click="dialogFormVisible02 = true">导出</el-button>
                  </el-form-item>
                </el-form>
                <el-dialog :center="true" title="超级导出" :visible.sync="dialogFormVisible02">
                  <el-form :model="form">
                    <el-form-item label="导出方式">
                      <el-radio-group v-model="exportType">
                        <el-radio label="txt"></el-radio>
                        <el-radio label="excel"></el-radio>
                      </el-radio-group>
                    </el-form-item>
                  </el-form>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible02 = false">取 消</el-button>
                    <el-button type="primary" @click="exportFile('stuinfoall')">确 定</el-button>
                  </div>
                </el-dialog>

                <el-button type="success" @click="dialog = true">高级查询</el-button>
                <el-drawer
                  size="37%"
                  title="超级无敌的高级查询"
                  :before-close="handleClose"
                  :visible.sync="dialog"
                  direction="rtl"
                  custom-class="demo-drawer"
                  ref="drawer"
                  :modal-append-to-body="true"
                >
                  <div class="demo-drawer__content">
                    <el-form :rules="rules" :inline="false" :model="HighSearchFrom" class="demo-form-inline">
                      <!-- <el-form-item label="学号">
                        <el-input v-model="formInline.user" placeholder="审批人"></el-input>
                      </el-form-item> -->
                      <el-form-item label="       姓名">
                        <el-input v-model="HighSearchFrom.name" placeholder="请输入姓名"></el-input>
                      </el-form-item>
                      <el-form-item label="      寝室号" prop="DormNum">
                        <el-input v-model="HighSearchFrom.DormNum" placeholder="请输入寝室号"></el-input>
                      </el-form-item>
                      <el-form-item label="      院校/专业/班级">
                        <div class="block" style="width: 200px">
                          <!-- <span class="demonstration">班级/专业/院校</span> -->
                          <el-cascader
                            :options="options"
                            :props="{ checkStrictly: true }"
                            placeholder="支持模糊查询"
                            clearable
                            filterable
                            v-model="classw"
                          ></el-cascader>
                        </div>
                      </el-form-item>
                    </el-form>
                    <div class="demo-drawer__footer">
                      <el-button @click="cancelForm">取 消</el-button>
                      <el-button type="primary" @click="$refs.drawer.closeDrawer()" :loading="loading">{{
                        loading ? '提交中 ...' : '确 定'
                      }}</el-button>
                    </div>
                  </div>
                </el-drawer>
              </el-header>
              <el-scrollbar style="height: 100%">
                <el-main>
                  <!-- 修改高度，可出现滚轮 -->
                  <el-table
                    id="stuinfo"
                    :data="stuinfoall"
                    height="680px"
                    :default-sort="{ prop: 'age', order: 'descending' }"
                  >
                    <el-table-column
                      prop="stuno"
                      label="学号"
                      width="100"
                      fixed="left"
                      sortable
                      :sort-method="sortDevName"
                    >
                    </el-table-column>
                    <el-table-column prop="name" label="姓名" width="100" fixed="left" sortable :sort-method="sortName">
                    </el-table-column>
                    <el-table-column prop="sex" label="性别" width="100"> </el-table-column>
                    <el-table-column prop="age" label="年龄" width="100" sortable> </el-table-column>
                    <el-table-column prop="nativePlace" label="籍贯" width="100"> </el-table-column>
                    <el-table-column prop="address" label="家庭住址" width="100"> </el-table-column>
                    <el-table-column prop="classes" label="班级" width="120"> </el-table-column>
                    <el-table-column prop="major" label="专业" width="100"> </el-table-column>
                    <el-table-column prop="college" label="学院" width="140"> </el-table-column>
                    <el-table-column prop="dormNum" label="寝室号" width="100"> </el-table-column>
                    <el-table-column prop="lengthOfSchooling" label="学制" width="100"> </el-table-column>
                    <el-table-column prop="yearOfAdmission" label="入学时间" width="100"> </el-table-column>
                    <el-table-column prop="statusOfStudent" label="状态"> </el-table-column>
                    <el-table-column fixed="right" label="操作" width="166">
                      <template slot-scope="scope">
                        <el-button @click="EditStuClick(scope.row)" size="mini" icon="el-icon-edit">编辑</el-button>

                        <el-popconfirm title="这是一段内容确定删除吗？" @confirm="DeleteStuClick(scope.row)">
                          <el-button slot="reference" size="mini" type="danger" icon="el-icon-delete">删除</el-button>
                          <!-- <el-button slot="reference">删除</el-button> -->
                        </el-popconfirm>
                      </template>
                    </el-table-column>
                  </el-table>

                  <!-- Form -->
                  <!-- form表单的rule为引入的规则数组，每个prop为对应规则 -->
                  <el-dialog title="学生基本信息" :visible.sync="dialogFormVisible">
                    <el-form
                      :model="StuForm"
                      status-icon
                      :rules="rules"
                      ref="StuForm"
                      label-width="100px"
                      class="demo-ruleForm demo-form-inline"
                      size="mini"
                      :inline="true"
                    >
                      <el-form-item label="学号">
                        <el-input disabled v-model="StuForm.stuno" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="姓名" prop="name">
                        <el-input v-model="StuForm.name"></el-input>
                      </el-form-item>
                      <el-form-item label="性别">
                        <el-input disabled v-model="StuForm.sex" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="年龄" prop="age">
                        <el-input v-model.number="StuForm.age"></el-input>
                      </el-form-item>
                      <el-form-item label="籍贯" prop="nativePlace">
                        <el-input v-model="StuForm.nativePlace" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="家庭住址" prop="address">
                        <el-input v-model="StuForm.address" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="班级" prop="pass">
                        <el-select v-model="StuForm.classes" placeholder="请选择活动区域" style="width: 100%">
                          <el-option label="地信22001" value="地信22001"></el-option>
                          <el-option label="地信22002" value="地信22002"></el-option>
                          <el-option label="地信22003" value="地信22003"></el-option>
                          <el-option label="地信22004" value="地信22004"></el-option>
                          <el-option label="地物22001" value="地物22001"></el-option>
                          <el-option label="地物22002" value="地物22002"></el-option>
                          <el-option label="地物22003" value="地物22003"></el-option>
                          <el-option label="地物22004" value="地物22004"></el-option>
                          <el-option label="地质22001" value="地质22001"></el-option>
                          <el-option label="地质22002" value="地质22002"></el-option>
                          <el-option label="地质22003" value="地质22003"></el-option>
                          <el-option label="地质22004" value="地质22004"></el-option>
                          <el-option label="大数据22001" value="大数据22001"></el-option>
                          <el-option label="大数据22002" value="大数据22002"></el-option>
                          <el-option label="大数据22003" value="大数据22003"></el-option>
                          <el-option label="大数据22004" value="大数据22004"></el-option>
                          <el-option label="艺传22001" value="艺传22001"></el-option>
                          <el-option label="艺传22002" value="艺传22002"></el-option>
                          <el-option label="艺传22003" value="艺传22003"></el-option>
                          <el-option label="艺传22004" value="艺传22004"></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item label="专业">
                        <el-input disabled v-model="StuForm.major" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="学院">
                        <el-input disabled v-model="StuForm.college" autocomplete="off"></el-input>
                      </el-form-item>

                      <el-form-item label="寝室号" prop="dormNum">
                        <el-input v-model="StuForm.dormNum" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="*注意">
                        <el-input placeholder="学院随专业修改后改变" autocomplete="off" disabled></el-input>
                      </el-form-item>
                      <el-form-item label="学制">
                        <el-input disabled v-model="StuForm.lengthOfSchooling" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="入学时间">
                        <el-input disabled v-model="StuForm.yearOfAdmission" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="状态">
                        <el-select v-model="StuForm.statusOfStudent" placeholder="请选择状态" style="width: 100%">
                          <el-option label="在读" value="在读"></el-option>
                          <el-option label="肄业" value="肄业"></el-option>
                          <el-option label="毕业" value="毕业"></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item size="medium" style="display: block">
                        <el-button type="primary" @click="submitFormstu(StuForm)">提交</el-button>
                        <el-button @click="resetForm('StuForm')">重置</el-button>
                      </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                      <el-button @click="dialogFormVisible = false">取 消</el-button>
                      <!-- <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button> -->
                    </div>
                  </el-dialog>
                  <!-- // 登录表单 -->
                  <!-- Form -->
                  <!-- form表单的rule为引入的规则数组，每个prop为对应规则 -->
                  <el-dialog title="欢迎登录学生信息管理系统" :visible.sync="dialogFormVisible05">
                    <el-form :model="Loginform">
                      <el-form-item label="账号" label-width="80px">
                        <el-input v-model="Loginform.stuno" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="密码" label-width="80px">
                        <el-input v-model="Loginform.password" autocomplete="off" type="password"></el-input>
                      </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                      <el-button type="primary" @click="Loginclick()">确 定</el-button>
                    </div>
                  </el-dialog>
                </el-main>
              </el-scrollbar>
            </el-container>
          </el-tab-pane>

          <el-tab-pane>
            <span slot="label"><i class="el-icon-pie-chart"></i>学院信息</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px"> </el-header>
              <el-scrollbar style="height: 100%">
                <el-main>
                  <el-table :data="CollegeAll" :inline="true" height="680px">
                    <el-table-column prop="college" label="学院" width="500"> </el-table-column>
                    <el-table-column prop="major" label="专业" width="500"> </el-table-column>
                    <el-table-column prop="classes" label="班级" width="200"> </el-table-column>
                  </el-table>
                </el-main>
              </el-scrollbar> </el-container
          ></el-tab-pane>
          <el-tab-pane>
            <span slot="label"><i class="el-icon-mobile"></i>寝室信息</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px"> </el-header>
              <el-scrollbar style="height: 100%">
                <el-main>
                  <el-table :data="dromNumAll" :inline="true" height="680px">
                    <el-table-column prop="stuno" label="学号" width="500"> </el-table-column>
                    <el-table-column prop="name" label="姓名" width="500"> </el-table-column>
                    <el-table-column prop="dormNum" label="寝室号" width="300"> </el-table-column>
                  </el-table>
                </el-main>
              </el-scrollbar> </el-container
          ></el-tab-pane>
          <el-tab-pane>
            <span slot="label"><i class="el-icon-help"></i>流动信息</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px">
                <el-button type="primary" @click="AddStuChangeClick">添加</el-button></el-header
              >
              <el-scrollbar style="height: 100%">
                <el-main>
                  <el-table :data="stuchangeAll" :inline="true" height="680px">
                    <el-table-column prop="stuno" label="学号" width="200"> </el-table-column>
                    <el-table-column prop="type" label="类型" width="170"> </el-table-column>
                    <el-table-column prop="depiction" label="描述" width="400"> </el-table-column>
                    <el-table-column prop="time" label="时间" width="200"> </el-table-column>
                    <el-table-column fixed="right" label="操作" width="166">
                      <template slot-scope="scope">
                        <el-button @click="EditChangeClick(scope.row)" size="mini" icon="el-icon-edit">编辑</el-button>

                        <el-popconfirm title="这是一段内容确定删除吗？" @confirm="DeleteChangeClick(scope.row)">
                          <el-button slot="reference" size="mini" type="danger" icon="el-icon-delete">删除</el-button>
                          <!-- <el-button slot="reference">删除</el-button> -->
                        </el-popconfirm>
                      </template>
                    </el-table-column>
                  </el-table>

                  <!-- Form -->
                  <!-- form表单的rule为引入的规则数组，每个prop为对应规则 -->
                  <el-dialog title="学生流动信息编辑" :visible.sync="dialogFormVisible03">
                    <el-form
                      :model="StuChangeForm"
                      status-icon
                      :rules="rules"
                      ref="StuForm"
                      label-width="50px"
                      class="demo-ruleForm demo-form-inline"
                      size="mini"
                    >
                      <el-form-item label="学号" prop="stuno">
                        <el-input :disabled="xv" v-model="StuChangeForm.stuno" autocomplete="off"></el-input>
                      </el-form-item>

                      <el-form-item label="类型" prop="pass">
                        <el-select v-model="StuChangeForm.type" placeholder="请选择流动类型" style="width: 100%">
                          <el-option label="转专业" value="转专业"></el-option>
                          <el-option label="毕业" value="毕业"></el-option>
                          <el-option label="肄业" value="肄业"></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item label="描述">
                        <el-input
                          type="text"
                          v-model="StuChangeForm.depiction"
                          autocomplete="off"
                          maxlength="25"
                          show-word-limit
                        ></el-input>
                      </el-form-item>

                      <el-form-item label="时间">
                        <el-input disabled v-model="StuChangeForm.time" autocomplete="off"></el-input>
                      </el-form-item>

                      <el-form-item size="medium">
                        <el-button type="primary" @click="submitFormchange(StuChangeForm)">提交</el-button>
                      </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                      <el-button @click="dialogFormVisible03 = false">取 消</el-button>
                    </div>
                  </el-dialog>
                </el-main>
              </el-scrollbar>
            </el-container></el-tab-pane
          >
          <el-tab-pane>
            <span slot="label"><i class="el-icon-s-order"></i>奖惩信息</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px">
                <el-button type="primary" @click="AddStuRePuClick">添加</el-button></el-header
              >
              <el-scrollbar style="height: 100%">
                <el-main>
                  <el-table :data="RePuAll" :inline="true" height="680px">
                    <el-table-column prop="id" label="ID" width="50"> </el-table-column>
                    <el-table-column prop="stuno" label="学号" width="100"> </el-table-column>
                    <el-table-column prop="type" label="类型" width="150"> </el-table-column>
                    <el-table-column prop="depiction" label="描述" width="400"> </el-table-column>
                    <el-table-column prop="time" label="时间" width="200"> </el-table-column>
                    <el-table-column fixed="right" label="操作" width="166">
                      <template slot-scope="scope">
                        <el-button @click="EditRePuClick(scope.row)" size="mini" icon="el-icon-edit">编辑</el-button>

                        <el-popconfirm title="这是一段内容确定删除吗？" @confirm="DeleteRePuClick(scope.row)">
                          <el-button slot="reference" size="mini" type="danger" icon="el-icon-delete">删除</el-button>
                          <!-- <el-button slot="reference">删除</el-button> -->
                        </el-popconfirm>
                      </template>
                    </el-table-column>
                  </el-table>
                  <!-- Form -->
                  <!-- form表单的rule为引入的规则数组，每个prop为对应规则 -->
                  <el-dialog title="学生奖惩信息编辑" :visible.sync="dialogFormVisible04">
                    <el-form
                      :model="StuRePuForm"
                      status-icon
                      :rules="rules"
                      ref="StuRePuForm"
                      label-width="50px"
                      class="demo-ruleForm demo-form-inline"
                      size="mini"
                    >
                      <el-form-item label="id">
                        <el-input disabled v-model="StuRePuForm.id" autocomplete="off"></el-input>
                      </el-form-item>
                      <el-form-item label="学号" prop="stuno">
                        <el-input :disabled="xv" v-model="StuRePuForm.stuno" autocomplete="off"></el-input>
                      </el-form-item>

                      <el-form-item label="类型" prop="pass">
                        <el-select v-model="StuRePuForm.type" placeholder="请选择奖惩类型" style="width: 100%">
                          <el-option label="奖励" value="奖励"></el-option>
                          <el-option label="惩罚" value="惩罚"></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item label="描述">
                        <el-input
                          type="text"
                          v-model="StuRePuForm.depiction"
                          autocomplete="off"
                          maxlength="25"
                          show-word-limit
                        ></el-input>
                      </el-form-item>

                      <el-form-item label="时间">
                        <el-input disabled v-model="StuRePuForm.time" autocomplete="off"></el-input>
                      </el-form-item>

                      <el-form-item size="medium">
                        <el-button type="primary" @click="submitFormrepu(StuRePuForm)">提交</el-button>
                      </el-form-item>
                    </el-form>
                  </el-dialog>
                </el-main>
              </el-scrollbar>
            </el-container></el-tab-pane
          >
          <el-tab-pane>
            <span slot="label"><i class="el-icon-tickets"></i>班级信息</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px"> </el-header>
              <el-scrollbar style="height: 100%">
                <el-main>
                  <el-table :data="ClassAll">
                    <el-table-column prop="classes" label="班级" width="400"> </el-table-column>
                    <el-table-column prop="stuno" label="学号" width="400"> </el-table-column>
                    <el-table-column prop="name" label="姓名" width="400"> </el-table-column>
                  </el-table>
                </el-main>
              </el-scrollbar> </el-container
          ></el-tab-pane>
          <!-- 信息服务 -->
          <el-tab-pane>
            <span slot="label">
              <el-badge :value="UnDeal()" class="item"> <i class="el-icon-info"></i>信息服务</el-badge></span
            >
            <el-container>
              <el-header style="text-align: right; font-size: 12px"> </el-header>
              <el-scrollbar style="height: 100%">
                <el-main>
                  <el-table :data="ServiceAll" :inline="true" height="680px" style="width: 100%">
                    <el-table-column prop="id" label="ID" width="100"> </el-table-column>
                    <el-table-column prop="stuno" label="学号" width="150"> </el-table-column>
                    <el-table-column prop="describe" label="描述" width="400"> </el-table-column>
                    <el-table-column prop="time" label="时间" width="300"> </el-table-column>
                    <el-table-column label="状态" width="120">
                      <template slot-scope="scope">
                        <el-tag type="success" effect="dark" v-if="scope.row.status == 0">已处理</el-tag>
                        <el-tag type="warning" effect="dark" v-if="scope.row.status == 1">待处理</el-tag>
                        <el-tag type="danger" effect="dark" v-if="scope.row.status == 2">拒绝处理</el-tag>
                      </template>
                    </el-table-column>
                    <el-table-column fixed="right" label="操作" width="166">
                      <template slot-scope="scope">
                        <el-button
                          @click="DealWith(scope.row, 0)"
                          size="mini"
                          icon="el-icon-success"
                          v-if="scope.row.status == 1"
                          >完成处理</el-button
                        >

                        <el-popconfirm title="确定拒绝处理吗？" @confirm="DealWith(scope.row, 2)">
                          <el-button
                            slot="reference"
                            size="mini"
                            type="danger"
                            icon="el-icon-error"
                            v-if="scope.row.status == 1"
                            >拒绝处理</el-button
                          >
                          <!-- <el-button slot="reference">删除</el-button> -->
                        </el-popconfirm>
                      </template>
                    </el-table-column>
                  </el-table>
                </el-main>
              </el-scrollbar>
            </el-container></el-tab-pane
          >
          <el-tab-pane>
            <span slot="label"><i class="el-icon-document-add"></i>信息上传</span>
            <el-header style="height: 180px">
              <el-upload
                class="upload-demo"
                ref="upload"
                :action="UploadUrl()"
                :on-preview="handlePreview"
                :on-remove="handleRemove"
                :before-remove="beforeRemove"
                multiple
                :limit="3"
                :file-list="fileList"
                :on-change="changeFile"
                :before-upload="beforeUpload"
                :on-success="handleSuccess"
                :on-error="handleError"
                :auto-upload="false"
                accept=".txt,.xls,.xlsx"
              >
                <el-button size="medium" type="primary">点击上传</el-button>
                <div slot="tip" class="el-upload__tip">目前只支持txt与excel，且不超过500kb</div>
              </el-upload></el-header
            >
            <el-container>
              <!-- accept:控制上传类型， :on-success="uploadSuccess"上传成功
                :on-error="uploadError"上传失败
                :on-change="changeFile"上传文件
                :before-upload="changeFile" 上传之前-->

              <el-table :data="UploadAll" :inline="true" height="600px">
                <el-table-column prop="id" label="ID" width="200"> </el-table-column>
                <el-table-column prop="filename" label="文件名" width="300"> </el-table-column>
                <el-table-column prop="time" label="时间" width="600"> </el-table-column>
              </el-table>
              <!-- <input type="file" accept=".xls,.xlsx" class="upload_file" :on-change="readExcel" /> -->
            </el-container>
          </el-tab-pane>

          <el-tab-pane>
            <span slot="label" @click="Updateechart()"> <i class="el-icon-receiving"></i>图表展示</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px">
                <el-button type="primary" icon="el-icon-printer" @click="getPdf()">下载报表</el-button></el-header
              >
              <el-scrollbar>
                <el-main id="pdfDom" :inline="true">
                  <div id="main" class="main" style="height: 350px; width: 550px; display: inline-block"></div>
                  <div
                    id="main2"
                    class="main"
                    style="height: 350px; width: 550px; display: inline-block; margin-top: -20px"
                  >
                    <el-card class="box-card" shadow="hover">
                      <!-- <div v-for="o in 4" :key="o" class="text item1">
                        {{ '列表内容 ' + o }}
                      </div> -->
                      <div class="text item1">学校总人数为:{{ this.stuinfoall.length }}</div>
                      <div class="text item1">学校人数较去年增长:{{ this.Stugroup() }}</div>
                      <div class="text item1">学校男女比例为：{{ this.Stusex() }}</div>
                      <div class="text item1">学生专业满意度：比较满意</div>
                    </el-card>
                  </div>
                  <div id="main3" class="main" style="height: 240px; width: 550px; display: inline-block"></div>
                  <div id="main4" class="main" style="height: 240px; width: 550px; display: inline-block"></div>
                </el-main>
              </el-scrollbar> </el-container
          ></el-tab-pane>
          <el-tab-pane>
            <span slot="label"> <i class="el-icon-receiving"></i>操作记录</span>

            <el-container>
              <el-header style="text-align: right; font-size: 12px"> </el-header>
              <el-scrollbar style="height: 100%">
                <el-main>
                  <el-table :data="OperateLogAll" :inline="true" height="680px">
                    <el-table-column prop="id" label="ID" width="200"> </el-table-column>
                    <el-table-column prop="stuno" label="学号" width="300"> </el-table-column>
                    <el-table-column prop="operate" label="操作" width="400"> </el-table-column>
                    <el-table-column prop="time" label="时间" width="300"> </el-table-column>
                  </el-table>
                </el-main>
              </el-scrollbar> </el-container
          ></el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import * as XLSX from 'xlsx'
import FileSaver from 'file-saver'
import { saveAs } from 'file-saver'
import moment from 'moment'
import html2canvas from 'html2canvas'
import htmlToPdf from './utils/htmlToPDF'
export default {
  name: 'HelloWorld',
  data() {
    var checkAge = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('年龄不能为空'))
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error('请输入数字值'))
        } else {
          if (value < 18) {
            callback(new Error('必须年满18岁'))
          } else {
            callback()
          }
        }
      }, 1000)
    }

    var validateDorm = (rule, value, callback) => {
      let re = /[1-9]-[1-6][0-3][0-9]/
      if (value === '') {
        callback(new Error('请输入寝室号'))
      } else if (!re.test(value)) {
        console.log(value)
        callback(new Error('寝室号格式应为x-xxx!'))
      } else {
        callback()
      }
    }
    var validateStuno = (rule, value, callback) => {
      let re = /20[0-2][0-4][0-9][0-9][0-9][0-9][0-9]/
      if (value === '') {
        callback()
      } else if (!re.test(value)) {
        console.log(value)
        callback(new Error('格式错误，请输入正确学号!'))
      } else {
        callback()
      }
    }
    var validateDorm02 = (rule, value, callback) => {
      let re = /[1-9]-[1-6][0-3][0-9]/
      if (value === '') {
        callback()
      } else if (!re.test(value)) {
        callback(new Error('寝室号格式应为x-xxx!'))
      }
    }

    const stuinfo = {
      yearOfAdmission: '2016-05-02',
      name: '王小虎',
      address: '上海市普陀区金沙江路 1518 弄',
      stuno: '',
      sex: '',
      age: '',
      nativePlace: '',
      classes: '',
      major: '',
      college: '',
      dormNum: '',
      lengthOfSchooling: '',
      statusOfStudent: ''
    }
    const StuForm = {
      yearOfAdmission: '2016-05-02',
      name: '王小虎',
      address: '上海市普陀区金沙江路 1518 弄',
      stuno: '',
      sex: '',
      age: '',
      nativePlace: '',
      classes: '',
      major: '',
      college: '',
      dormNum: '',
      lengthOfSchooling: '',
      statusOfStudent: ''
    }

    return {
      htmlTitle: '信息报表', //这个也是固定写法，pdf文件下载的名称

      //表单测试规则部分
      //表单测试部分规则返回值

      StuForm,
      rules: {
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' },
          { min: 1, max: 5, message: '长度在 1 到 5 个字符', trigger: 'blur' }
        ],
        nativePlace: [
          { required: true, message: '请输入籍贯', trigger: 'blur' },
          { min: 1, max: 5, message: '长度在 1 到 10 个字符', trigger: 'blur' }
        ],
        address: [
          { required: true, message: '请输入家庭住址', trigger: 'blur' },
          { min: 1, max: 5, message: '长度在 1 到 10 个字符', trigger: 'blur' }
        ],

        dormNum: [{ validator: validateDorm, trigger: 'blur' }],
        DormNum: [{ validator: validateDorm02, trigger: 'blur' }],
        age: [{ validator: checkAge, trigger: 'blur' }],
        stuno: [{ validator: validateStuno, trigger: 'blur' }],
        depiction: [{ required: true, message: '请输入姓名', trigger: 'blur' }]
      },

      tabPosition: 'left',
      stuinfo,
      StuInfoForm: {
        stuno: ''
      },
      stuinfoall: [],
      CollegeAll: [],
      dromNumAll: [],
      stuchangeAll: [],
      RePuAll: [],
      // CollegeAll: [],
      ServiceAll: [],
      ClassAll: [],
      UploadAll: [],
      user: {
        name: '地信22001 刘超',
        stuno: 202001354,
        password: 123
      },
      Loginform: {
        name: '游客(请登录)',
        stuno: null,
        password: null
      },

      //存储上传文件地址以及上传名称
      fileList: [
        // {
        //   name: '震惊，滑稽少男唐龙竟然！',
        //   url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        // },
        // {
        //   name: '李坤又没来上机',
        //   url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        // }
      ],
      formInline: {
        user: '',
        region: ''
      },
      upload_file: '',

      uploaddata: [],
      txtfileString: '',
      //编辑弹窗
      dialogFormVisible: false,

      formLabelWidth: '120px',
      props: {
        // msg: String
      },
      options: [
        {
          value: '地球科学学院',
          label: '地球科学学院',
          children: [
            {
              value: '地信',
              label: '地信',
              children: [
                {
                  value: '地信22001',
                  label: '地信22001'
                },
                {
                  value: '地信22002',
                  label: '地信22002'
                },
                {
                  value: '地信22003',
                  label: '地信22003'
                },
                {
                  value: '地信22004',
                  label: '地信22004'
                }
              ]
            },
            {
              value: '地质',
              label: '地质',
              children: [
                {
                  value: '地质22001',
                  label: '地质22001'
                },
                {
                  value: '地质22002',
                  label: '地质22002'
                },
                {
                  value: '地质22003',
                  label: '地质22003'
                },
                {
                  value: '地质22004',
                  label: '地质22004'
                }
              ]
            }
          ]
        },
        {
          value: '地球物理学院',
          label: '地球物理学院',
          children: [
            {
              value: '地物',
              label: '地物',
              children: [
                {
                  value: '地物22001',
                  label: '地物22001'
                },
                {
                  value: '地物22002',
                  label: '地物22002'
                },
                {
                  value: '地物22003',
                  label: '地物22003'
                },
                {
                  value: '地物22004',
                  label: '地物22004'
                }
              ]
            },
            {
              value: '大数据',
              label: '大数据',
              children: [
                {
                  value: '大数据22001',
                  label: '大数据22001'
                },
                {
                  value: '大数据22002',
                  label: '大数据22002'
                },
                {
                  value: '大数据22003',
                  label: '大数据22003'
                },
                {
                  value: '大数据22004',
                  label: '大数据22004'
                }
              ]
            }
          ]
        },
        {
          value: '艺术与传媒学院',
          label: '艺术与传媒学院',
          children: [
            {
              value: '艺传',
              label: '艺传',
              children: [
                {
                  value: '艺传22001',
                  label: '艺传22001'
                },
                {
                  value: '艺传22002',
                  label: '艺传22002'
                },
                {
                  value: '艺传22003',
                  label: '艺传22003'
                },
                {
                  value: '艺传22004',
                  label: '艺传22004'
                }
              ]
            }
          ]
        }
      ],
      //高级搜索
      table: false,
      dialog: false,
      loading: false,
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      formLabelWidth_h: '120px',
      timer: null,
      HighSearchFrom: {
        name: '',
        DormNum: '',
        classes: '',
        major: '',
        college: ''
      },
      classw: '',
      dialogFormVisible02: false,
      dialogFormVisible03: false,
      dialogFormVisible04: false,
      exportType: '',
      OperateLogAll: [],
      StuChangeForm: {
        stuno: '',
        type: '',
        depiction: '',
        time: ''
      },
      xv: false,
      StuRePuForm: {
        id: 0,
        stuno: '',
        type: '',
        depiction: '',
        time: ''
      },

      chartoption01: {
        title: {
          text: '学院、专业、班级人数统计图'
        },
        visualMap: {
          type: 'continuous',
          min: 0,
          max: 55,
          inRange: {
            color: ['#2F93C8', '#AEC48F', '#FFDB5C', '#F98862']
          }
        },
        series: {
          type: 'sunburst',
          data: [
            {
              name: '长江大学',
              children: [
                {
                  name: '地科院',
                  value: 15,
                  children: [
                    {
                      name: '地信',
                      value: 2,
                      children: [
                        {
                          name: '地信22001',
                          value: 1
                        },
                        {
                          name: '地信22001',
                          value: 1
                        },
                        {
                          name: '地信22003',
                          value: 1
                        },
                        {
                          name: '地信22004',
                          value: 1
                        }
                      ]
                    },
                    {
                      name: '地质',
                      value: 5,
                      children: [
                        {
                          name: '地质22001',
                          value: 1
                        },
                        {
                          name: '地质22001',
                          value: 1
                        },
                        {
                          name: '地质22003',
                          value: 1
                        },
                        {
                          name: '地质22004',
                          value: 1
                        }
                      ]
                    },
                    {
                      name: '地产',
                      value: 5,
                      children: [
                        {
                          name: '地产22001',
                          value: 5
                        }
                      ]
                    }
                  ]
                },
                {
                  name: '地物院',
                  children: [
                    {
                      name: '地物',
                      value: 4,
                      children: [
                        {
                          name: '地物22001',
                          value: 1
                        },
                        {
                          name: '地物22001',
                          value: 1
                        },
                        {
                          name: '地物22003',
                          value: 1
                        },
                        {
                          name: '地物22004',
                          value: 1
                        }
                      ]
                    },
                    {
                      name: '大数据',
                      value: 4,
                      children: [
                        {
                          name: '大数据22001',
                          value: 1
                        },
                        {
                          name: '大数据2001',
                          value: 1
                        },
                        {
                          name: '大数据22003',
                          value: 1
                        },
                        {
                          name: '大数据22004',
                          value: 1
                        }
                      ]
                    }
                  ]
                },
                {
                  name: '艺传院',
                  value: 10,
                  children: [
                    {
                      name: '艺传',
                      value: 5,
                      itemStyle: {
                        color: 'red'
                      },
                      children: [
                        {
                          name: '艺传22001',
                          value: 1
                        },
                        {
                          name: '艺传2001',
                          value: 1
                        },
                        {
                          name: '艺传22003',
                          value: 1
                        },
                        {
                          name: '艺传22004',
                          value: 1
                        }
                      ]
                    },
                    {
                      name: '美妆',
                      value: 2,
                      children: [
                        {
                          name: '美妆21901',
                          value: 1
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ],
          radius: [0, '90%'],
          label: {
            rotate: 'radial'
          }
        }
      },

      chartoption03: {
        title: {
          text: '奖惩对比图'
        },
        color: ['#5470C6', '#EE6666'],
        tooltip: {
          trigger: 'none',
          axisPointer: {
            type: 'cross'
          }
        },
        legend: {},
        grid: {
          top: 70,
          bottom: 50
        },
        xAxis: [
          {
            type: 'category',
            axisTick: {
              alignWithLabel: true
            },
            axisLine: {
              onZero: false,
              lineStyle: {
                color: '#EE6666'
              }
            },
            axisPointer: {
              label: {
                formatter: function (params) {
                  return '惩罚  ' + params.value + (params.seriesData.length ? '：' + params.seriesData[0].data : '')
                }
              }
            },
            // prettier-ignore
            data: ['2022', '2023']
          },
          {
            type: 'category',
            axisTick: {
              alignWithLabel: true
            },
            axisLine: {
              onZero: false,
              lineStyle: {
                color: '#5470C6'
              }
            },
            axisPointer: {
              label: {
                formatter: function (params) {
                  return '奖励  ' + params.value + (params.seriesData.length ? '：' + params.seriesData[0].data : '')
                }
              }
            },
            // prettier-ignore
            data: ['2022', '2023']
          }
        ],
        yAxis: [
          {
            type: 'value'
          }
        ],
        series: [
          {
            name: '奖励',
            type: 'line',
            xAxisIndex: 1,
            smooth: true,
            emphasis: {
              focus: 'series'
            },
            data: [2.6, 5.9]
          },
          {
            name: '惩罚',
            type: 'line',
            smooth: true,
            emphasis: {
              focus: 'series'
            },
            data: [3.9, 5.9]
          }
        ]
      },
      chartoption04: {
        title: {
          text: '信息服务处理统计'
        },
        tooltip: {
          trigger: 'item'
        },
        legend: {
          top: '5%',
          left: 'center'
        },
        series: [
          {
            name: '信息服务完成状况',
            type: 'pie',
            radius: ['40%', '70%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            label: {
              show: false,
              position: 'center'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 40,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: [
              { value: 2, name: '待处理' },
              { value: 1, name: '已处理' },
              { value: 1, name: '未处理' }
            ]
          }
        ]
      },
      echartsdealform: {
        finish: 0,
        wait: 0,
        reject: 0
      },
      echartsrepuform: {
        Re: [],
        Pu: []
      },
      echartsstuform: {
        name: '长江大学',
        children: [
          {
            name: '地科院',
            value: 15,
            children: [
              {
                name: '地信',
                value: 2,
                children: [
                  {
                    name: '地信22001',
                    value: 1
                  },
                  {
                    name: '地信22002',
                    value: 1
                  },
                  {
                    name: '地信22003',
                    value: 1
                  },
                  {
                    name: '地信22004',
                    value: 1
                  }
                ]
              },
              {
                name: '地质',
                value: 5,
                children: [
                  {
                    name: '地质22001',
                    value: 1
                  },
                  {
                    name: '地质22002',
                    value: 1
                  },
                  {
                    name: '地质22003',
                    value: 1
                  },
                  {
                    name: '地质22004',
                    value: 1
                  }
                ]
              },
              {
                name: '地产',
                value: 5,
                children: [
                  {
                    name: '地产22001',
                    value: 5
                  }
                ]
              }
            ]
          },
          {
            name: '地物院',
            children: [
              {
                name: '地物',
                value: 4,
                children: [
                  {
                    name: '地物22001',
                    value: 1
                  },
                  {
                    name: '地物22002',
                    value: 1
                  },
                  {
                    name: '地物22003',
                    value: 1
                  },
                  {
                    name: '地物22004',
                    value: 1
                  }
                ]
              },
              {
                name: '大数据',
                value: 4,
                children: [
                  {
                    name: '大数据22001',
                    value: 1
                  },
                  {
                    name: '大数据22002',
                    value: 1
                  },
                  {
                    name: '大数据22003',
                    value: 1
                  },
                  {
                    name: '大数据22004',
                    value: 1
                  }
                ]
              }
            ]
          },
          {
            name: '艺传院',
            value: 10,
            children: [
              {
                name: '艺传',
                value: 5,
                itemStyle: {
                  color: 'red'
                },
                children: [
                  {
                    name: '艺传22001',
                    value: 1
                  },
                  {
                    name: '艺传22002',
                    value: 1
                  },
                  {
                    name: '艺传22003',
                    value: 1
                  },
                  {
                    name: '艺传22004',
                    value: 1
                  }
                ]
              },
              {
                name: '美妆',
                value: 2,
                children: [
                  {
                    name: '美妆21901',
                    value: 1
                  }
                ]
              }
            ]
          }
        ]
      },
      dialogFormVisible05: false
    }
  },

  mounted() {
    //加载信息

    //this.showchart04()
    //学生基本信息
    // this.axios.get('http://localhost:8081/stuinfo').then((response) => {
    //   //console.log(response)
    //   this.stuinfoall = []
    //   response.data.forEach((el) => {
    //     this.stuinfoall.push(el)
    //     //console.log(el)
    //   })
    //   console.log(this.stuinfoall)
    // })
    //this.getdata('stuinfo', 'stuinfoall')

    //学院专业信息
    // this.axios.get('http://localhost:8081/college').then((response) => {
    //   //console.log(response)
    //   this.CollegeAll = []
    //   response.data.forEach((el) => {
    //     this.CollegeAll.push(el)
    //   })
    //   //console.log(this.CollegeAll)
    // })
    //this.getdata('college', 'CollegeAll')
    //寝室信息
    // this.axios.get('http://localhost:8081/dorm').then((response) => {
    //   //console.log(response)
    //   this.dromNumAll = []
    //   response.data.forEach((el) => {
    //     this.dromNumAll.push(el)
    //   })
    //   //console.log(this.dromNumAll)
    // })
    //this.getdata('dorm', 'dromNumAll')
    //学生变动信息
    // this.axios.get('http://localhost:8081/stuchange').then((response) => {
    //   //console.log(response)
    //   this.stuchangeAll = []
    //   response.data.forEach((el) => {
    //     this.stuchangeAll.push(el)
    //   })
    //   //console.log(this.stuchangeAll)
    // })
    // this.getdata('stuchange', 'stuchangeAll')
    //奖惩信息
    // this.axios.get('http://localhost:8081/repu').then((response) => {
    //   //console.log(response)
    //   this.RePuAll = []
    //   response.data.forEach((el) => {
    //     this.RePuAll.push(el)
    //   })
    //   //console.log(this.RePuAll)
    // })
    //this.getdata('repu', 'RePuAll')
    //服务信息
    // this.axios.get('http://localhost:8081/service').then((response) => {
    //   //console.log(response)
    //   this.ServiceAll = []
    //   response.data.forEach((el) => {
    //     this.ServiceAll.push(el)
    //   })
    //   //console.log(this.ServiceAll)
    // }),
    // this.getdata('service', 'ServiceAll')
    //班级信息
    // this.axios.get('http://localhost:8081/class').then((response) => {
    //   //console.log(response)
    //   this.ClassAll = []
    //   response.data.forEach((el) => {
    //     this.ClassAll.push(el)
    //   })
    //   //console.log(this.ServiceAll)
    // })
    // this.getdata('class', 'ClassAll')
    //上传信息
    // this.axios.get('http://localhost:8081/upload').then((response) => {
    //   //console.log(response)
    //   this.UploadAll = []
    //   response.data.forEach((el) => {
    //     this.UploadAll.push(el)
    //   })
    //   //console.log(this.UploadAll)
    // })
    //this.getdata('upload', 'UploadAll')
    //this.getdata('operatelog', 'OperateLogAll')
    //echarts
    this.drawChart('main', this.chartoption01, 550, 350)
    //this.drawChart('main2', this.chartoption02)
    this.drawChart('main3', this.chartoption03, 240, 550)
    this.drawChart('main4', this.chartoption04, 240, 550)
  },

  methods: {
    updateinfo() {
      this.getdata('stuinfo', 'stuinfoall')
      this.getdata('college', 'CollegeAll')
      this.getdata('dorm', 'dromNumAll')
      this.getdata('stuchange', 'stuchangeAll')
      this.getdata('repu', 'RePuAll')
      this.getdata('service', 'ServiceAll')
      this.getdata('class', 'ClassAll')
      this.getdata('upload', 'UploadAll')
      this.getdata('operatelog', 'OperateLogAll')
    },
    //获取数据挂载优化 挂载优化
    getdata(url, dataAll) {
      console.log('http://localhost:8081/' + url)
      this.axios.get('http://localhost:8081/' + url).then((response) => {
        //console.log(response)
        //实现数据导入复用
        this[dataAll] = []
        response.data.forEach((el) => {
          this[dataAll].push(el)
        })
        // if (dataAll == 'ServiceAll') {
        //   this.showchart04()
        //   this.drawChart()
        // }
        // console.log(dataAll)
      })
    },
    //获取所有学生信息
    getStuInfoAll() {
      this.axios.get('http://localhost:8081/stuinfo').then((response) => {
        console.log(response)
        // console.log(this.tableData)
        // var stuinfoall = []
        this.stuinfoall = []
        response.data.forEach((el) => {
          this.stuinfoall.push(el)
          console.log(el)
        })
        console.log(this.stuinfoall)
      })
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    //通过学号获取学生信息
    getsutinfoBystuno(id) {
      //console.log(id)
      if (id != '') {
        this.axios
          .post('http://localhost:8081/stuinfo', this.$qs.stringify({ id }))
          .then((response) => {
            console.log(response)
            this.stuinfoall = []
            // console.log(this.tableData)
            if (response.data != '') {
              this.opensuccess('查询成功，请查看结果')
              this.stuinfo.stuno = response.data.stuno
              this.stuinfo.name = response.data.name
              this.stuinfo.sex = response.data.sex
              this.stuinfo.age = response.data.age
              this.stuinfo.nativePlace = response.data.nativePlace
              this.stuinfo.address = response.data.address
              this.stuinfo.classes = response.data.classes
              this.stuinfo.major = response.data.major
              this.stuinfo.college = response.data.college
              this.stuinfo.dormNum = response.data.dormNum
              this.stuinfo.lengthOfSchooling = response.data.lengthOfSchooling
              this.stuinfo.yearOfAdmission = response.data.yearOfAdmission
              this.stuinfo.statusOfStudent = response.data.statusOfStudent
              this.stuinfoall.push(this.stuinfo)
              console.log(this.stuinfo)
            } else {
              this.openfail('查询结果为空，请输入正确学号')
            }
          })
          .catch((err) => {
            this.openfail(err)
          })
      } else {
        this.openfail('请输入学号！')
      }
    },

    // resetForm(formName) {
    //   this.$refs[formName].resetFields()
    // }

    //element ui 上传部分功能
    handleRemove(file, fileList) {
      let uid = file.uid
      console.log(uid)
      for (let i = 0; i < this.fileList.length; i++) {
        if (this.fileList[i].uid == uid) {
          this.fileList.splice(i, 1)
        }
      }
      this.fileList.console.log(file, fileList)
    },
    handlePreview(file) {
      console.log(file)
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`
      )
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`)
    },

    //上传文件
    //控制上传文件的类型，与accpet控制目的相同，但防止有绕过accept的操作
    beforeUpload(file) {
      console.log('before upload')
      console.log(file)
      let extension = file.name.substring(file.name.lastIndexOf('.') + 1)
      let size = file.size / 1024 / 1024
      if (extension !== 'xlsx' || extension !== 'xls' || extension !== 'txt') {
        this.$message.warning('只能上传后缀是.xlsx或.xls或txt的文件')
      }
      if (size > 10) {
        this.$message.warning('文件大小不得超过10M')
      }
    },
    //暂时用不到，未完善
    uploadFile(file) {
      if (file.length === 0) {
        this.$message.warning('请上传文件')
      } else {
        let form = new FormData()
        form.append('file', file)
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/file/uploadExcel',
          headers: {
            'Content-type': 'multipart/form-data'
          },
          data: form
        }).then(
          (res) => {
            this.opensuccess('上传成功，请查看上传结果.返回值：' + res)
          },
          (err) => {
            this.openfail(err.response)
          }
        )
      }
    },
    //上传文件，且单次上传一个（当文件选择后触发的函数）
    changeFile(file, fileList) {
      console.log(file)
      console.log(file.raw)
      this.fileList.push(file.raw)
      console.log(this.fileList)

      // 解析上传的文件
      let type = file.name.split('.')
      if (type[1] == 'txt') {
        this.UploadTxt(file)

        // console.log('是' + type[1])
        //后端上传修改视图功能已经屏蔽了，记得开启
      } else if (type[1] == 'xlsx' || type[1] == 'xls') {
        //console.log(type[1])
        console.log(file.raw)
        //this.readFileToJSON(file)
        this.readExcel(file)
      }
      //自带上传所有的方法，暂时不调用
      this.getdata('upload', 'UploadAll')
    },
    readExcel(file) {
      //注意，导入的时候，表格的第一行为表头，不会作为数据行
      // const type = file.name.split('.')[1]
      // if (!['xlsx', 'xls'].includes(type)) {
      //   this.$message({ type: 'warning', message: '文件格式错误！请重新选择' })
      //   return
      // }
      //创建一个FileReader对象
      const reader = new FileReader()
      const result = [] // 保存转化成功的 json格式
      //定义一个回调函数，当文件读取完成时执行
      reader.onload = (e) => {
        //获取二进制字符串
        const data = e.target.result
        //解析为工薄对象
        const wb = XLSX.read(data, {
          type: 'binary',
          cellDates: true
        })
        // 这里需要遍历，因为 excel 左下角有多张 sheet 表，如果只需要第一张表就不用遍历
        wb.SheetNames.forEach((sheetName) => {
          result.push({
            sheetName: sheetName,
            sheet: XLSX.utils.sheet_to_json(wb.Sheets[sheetName]) // 生成JSON表格内容
          })
        })

        // 处理 json 格式数据
        // const test = []
        // for (let item of result) {
        //   let time = null
        //   // excel导出json格式数据中有关时间的转换（因为导出json的时间格式为数字了，所以需要转换）
        //   if (typeof item['yearOfAdmission'] === 'number') {
        //     // time = new Date(1900, 0, item['时间'] - 1).toLocaleDateString()
        //     this.convertExcelDateFormat(item, 'yearOfAdmission')
        //   }
        // }
        //console.log(test)
        // console.log(result[0].sheetName)
        // console.log(result[0])
        for (let i = 0; i < result[0].sheet.length; i++) {
          console.log(result[0].sheet[i])
          this.uploadexcelpart(result[0].sheet[i], result[0].sheetName)
        }
      }
      //将excel转换为二进制字符串
      reader.readAsBinaryString(file.raw)
    },

    uploadexcelpart(stu, name) {
      let date = new Date()
      console.log(name)
      if (stu != '') {
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/stuinfo/excelupload',
          data: this.$qs.stringify({
            filename: name,
            time: date.toLocaleDateString(),
            stuno: stu.stuno,
            name: stu.name,
            sex: stu.sex,
            Age: stu.Age,
            nativePlace: stu.nativePlace,
            address: stu.address,
            classes: stu.classes,
            Major: stu.major,
            College: stu.college,
            DormNum: stu.dormNum,
            lengthOfSchooling: stu.lengthOfSchooling,
            yearOfAdmission: stu.yearOfAdmission,
            statusOfStudent: stu.statusOfStudent
          }),
          headers: {
            'Content-type': 'application/x-www-form-urlencoded'
          }
        })
          .then((res) => {
            this.opensuccess('上传成功，请查看上传结果')
            console.log(res.data)
            this.getdata('stuinfo', 'stuinfoall')
            this.getdata('operatelog', 'OperateLogAll')
          })
          .catch((err) => {
            this.openfail(err.response)
            console.log(err.response)
          })
      } else if (stu == '') {
        this.openfail('excel解析为空')
      }
    },
    //文本上传
    UploadTxt(file) {
      //let file = this.uploadFiles[0]
      let reader = new FileReader()
      // abort none 中断读取
      // readAsBinaryString file 将文件读取为二进制码，通常我们将它传送到后端，后端可以通过这段字符串存储文件
      // readAsDataURL file 将文件读取为 DataURL，一段以 data: 开头的字符串，这段字符串的实质就是 Data URL，Data URL是一种将小文件直接嵌入文档的方案。这里的小文件通常是指图像与 html 等格式的文件
      // readAsText file, [encoding] 将文件读取为文本，读取的结果即是这个文本文件中的内容
      reader.readAsText(file.raw)
      // onabort 中断时触发
      // onerror 出错时触发
      // onload 文件读取成功完成时触发
      // onloadend 读取完成触发，无论成功或失败
      // onloadstart 读取开始时触发
      // onprogress 读取中
      reader.onload = (e) => {
        // 读取文件内容
        this.txtfileString = e.target.result
        let date = new Date()
        console.log(date.toLocaleDateString())
        //上传
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/stuinfo/txtupload',
          data: this.$qs.stringify({
            txtdata: this.txtfileString,
            filename: file.name,
            time: date.toLocaleDateString()
          }),
          headers: {
            'Content-type': 'application/x-www-form-urlencoded'
          }
        })
          .then((res) => {
            this.opensuccess('上传成功，请查看上传结果')
            console.log(res.data)
            this.updateinfo()
          })
          .catch((err) => {
            this.openfail(err.response)
          })
        // 接下来可对文件内容进行处理
        //let data[]=fileString.split(' ')
        //分割字符串
        //   console.log(fileString)
        //   let fdata = fileString.split('\n')

        // }
        //   for (let i = 0; i < 2; i++) {
        //     this.uploaddata[i] = fdata[i].split('/ |\n/')
        //   }
        //   console.log(fdata)
        //   console.log(this.uploaddata)
      }
    },
    // 文件上传成功时的钩子
    handleSuccess(res, file, fileList) {
      this.$message.success('文件上传成功')
    },
    // 文件上传失败时的钩子
    handleError(err, file, fileList) {
      this.$message.error('文件上传失败')
    },
    UploadUrl: function () {
      // 因为action参数是必填项，我们使用二次确认进行文件上传时，直接填上传文件的url会因为没有参数导致api报404，所以这里将action设置为一个返回为空的方法就行，避免抛错
      return 'none'
    },
    //删除修改操作实现

    //解析excel文件(后期修改，一定可以的)
    // readExcel(e) {
    //   const f = e.file
    //   const reader = new FileReader() // 使用 FileReader 读取数据
    //   reader.onload = function (e) {
    //     // 数据读取完成后的回调函数
    //     const data = new Uint8Array(e.target.result)
    //     const workbook = XLSX.read(data, { type: 'array' }) // workbook 是 xlsx 解析 excel 后返回的对象

    //     const firstSheetName = workbook.SheetNames[0] // 获取第一个 sheet 的名字
    //     const worksheet = workbook.Sheets[firstSheetName] // 获取第一个 sheet 的内容
    //     const res = XLSX.utils.sheet_to_json(worksheet) // 使用 utils 里的方法转换内容为便于使用的数组
    //     console.log(res)
    //     // 下面就是自己对数组进行操作就行了
    //     // const list = res.map((item) => {
    //     //   return {
    //     //     keyword: item.keyword,
    //     //     weight: item.weight
    //     //   }
    //     // })

    //     // wordObj.setKeys([...wordObj.keys, ...list])
    //   }
    //   reader.readAsArrayBuffer(f) // 读取数据
    // },
    //echarts 图表使用
    drawChart(id, option, heigth, width) {
      //echart图表

      //解决echart无法捕捉宽高在vue-element框架中
      // Object.defineProperty(document.getElementsByClassName(id), 'clientWidth', {
      //   get: function () {
      //     return width
      //   }
      // })
      // Object.defineProperty(document.getElementsByClassName(id), 'clientHeight', {
      //   get: function () {
      //     return heigth
      //   }
      // })

      // 基于准备好的dom，初始化echarts实例
      var ROOT_PATH = 'https://echarts.apache.org/examples'
      var chartDom = document.getElementById(id)
      var myChart = this.$echarts.init(chartDom)
      myChart.resize() //重绘,动态获取options时不会出现渲染异常
      option && myChart.setOption(option, true)

      // myChart.clear()
    },
    onSubmit() {
      console.log('submit!')
    },

    //奖惩信息操作
    //编辑学生流动信息操作
    EditRePuClick(repuinfo) {
      console.log(repuinfo)
      this.dialogFormVisible04 = true
      this.xv = true
      this.restRePuForm()
      this.StuRePuForm.id = repuinfo.id
      this.StuRePuForm.stuno = repuinfo.stuno
      this.StuRePuForm.type = repuinfo.type
      this.StuRePuForm.depiction = repuinfo.depiction
      this.StuRePuForm.time = repuinfo.time
    },
    //提交奖惩信息内容
    submitFormrepu(repuform) {
      console.log(repuform)
      if (this.xv) {
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/repu/editrepuinfo',
          data: this.$qs.stringify({
            id: repuform.id,
            stuno: repuform.stuno,
            type: repuform.type,
            depiction: repuform.depiction,
            time: repuform.time
          }),
          headers: {
            'Content-type': 'application/x-www-form-urlencoded'
          }
        })
          .then((res) => {
            this.opensuccess('修改成功，请查看修改结果')

            console.log(res.data)
            if (res.data) {
              this.dialogFormVisible04 = false
              this.updateinfo()
            } else {
              alert('更新失败')
            }
          })
          .catch((err) => {
            this.openfail(err.response)
          })
      } else {
        //alert(999999)
        this.insertRePuinfo()
      }
    },
    //删除奖惩信息
    DeleteRePuClick(repuinfo) {
      console.log(repuinfo)
      this.axios({
        method: 'post',
        url: 'http://localhost:8081/repu/deleteRePuByStuno',
        data: this.$qs.stringify({
          id: repuinfo.id
        }),
        headers: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
        .then((res) => {
          this.dialogFormVisible = false
          this.opensuccess('删除成功，请查看删除后结果')
          console.log(res.data)
          if (res.data) {
            this.updateinfo()
            //this.getdata('operatelog', 'OperateLogAll')
          } else {
            // alert('更新失败')
            this.openfail('返回值为空，请查看控制台')
            console.log(res.data)
          }
        })
        .catch((err) => {
          this.openfail(err.response)
        })
    },
    //添加学生奖惩信息
    AddStuRePuClick() {
      this.restRePuForm()
      let date = new Date()
      let year = date.getFullYear()
      let month = (date.getMonth() + 1).toString().padStart(2, '0')
      let day = date.getDate().toString().padStart(2, '0')
      var time = year + '-' + month + '-' + day
      //console.log(time);
      this.StuRePuForm.time = time
      this.dialogFormVisible04 = true
      this.xv = false
      this.StuRePuForm.id = 857857
    },
    //上传奖惩信息
    insertRePuinfo() {
      console.log(this.StuRePuForm)
      //alert(this.StuRePuForm.id)
      if (
        this.StuRePuForm.stuno == '' ||
        this.StuRePuForm.type == '' ||
        this.StuRePuForm.depiction == '' ||
        this.StuRePuForm.time == ''
      ) {
        this.openfail('请输入完整数据！')
      } else if (
        this.StuRePuForm.stuno !== '' &&
        this.StuRePuForm.type !== '' &&
        this.StuRePuForm.depiction !== '' &&
        this.StuRePuForm.time !== ''
      ) {
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/repu/insertrepuinfo',
          data: this.$qs.stringify({
            id: this.StuRePuForm.id,
            stuno: this.StuRePuForm.stuno,
            type: this.StuRePuForm.type,
            depiction: this.StuRePuForm.depiction,
            time: this.StuRePuForm.time
          }),
          headers: {
            'Content-type': 'application/x-www-form-urlencoded'
          }
        })
          .then((res) => {
            this.dialogFormVisible04 = false
            this.opensuccess('添加成功，请查看删除后结果')
            console.log(res.data)
            if (res.data) {
              this.updateinfo()
            } else {
              this.openfail('返回值为空，请查看控制台')
              console.log(res.data)
            }
          })
          .catch((err) => {
            this.openfail(err.response)
          })
      }
    },
    //添加学生流动信息
    AddStuChangeClick() {
      this.restChangeForm()
      let date = new Date()
      let year = date.getFullYear()
      let month = (date.getMonth() + 1).toString().padStart(2, '0')
      let day = date.getDate().toString().padStart(2, '0')
      var time = year + '-' + month + '-' + day
      //console.log(time);
      this.StuChangeForm.time = time
      this.dialogFormVisible03 = true
      this.xv = false
    },

    //上传添加信息
    insertChangeinfo() {
      if (
        this.StuChangeForm.stuno == '' ||
        this.StuChangeForm.type == '' ||
        this.StuChangeForm.depiction == '' ||
        this.StuChangeForm.time == ''
      ) {
        this.openfail('请输入完整数据！')
      } else if (
        this.StuChangeForm.stuno !== '' &&
        this.StuChangeForm.type !== '' &&
        this.StuChangeForm.depiction !== '' &&
        this.StuChangeForm.time !== ''
      ) {
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/stuchange/insertChangechangeinfo',
          data: this.$qs.stringify({
            stuno: this.StuChangeForm.stuno,
            type: this.StuChangeForm.type,
            depiction: this.StuChangeForm.depiction,
            time: this.StuChangeForm.time
          }),
          headers: {
            'Content-type': 'application/x-www-form-urlencoded'
          }
        })
          .then((res) => {
            this.dialogFormVisible = false
            this.opensuccess('添加成功，请查看删除后结果')
            console.log(res.data)
            if (res.data) {
              this.updateinfo()
            } else {
              this.openfail('返回值为空，请查看控制台')
              console.log(res.data)
            }
          })
          .catch((err) => {
            this.openfail(err.response)
          })
      }
    },
    //编辑学生流动信息操作
    EditChangeClick(changeinfo) {
      console.log(changeinfo)
      this.dialogFormVisible03 = true
      this.xv = true
      this.restChangeForm()
      this.StuChangeForm.stuno = changeinfo.stuno
      this.StuChangeForm.type = changeinfo.type
      this.StuChangeForm.depiction = changeinfo.depiction
      this.StuChangeForm.time = changeinfo.time
    },
    DeleteChangeClick(changeinfo) {
      console.log(changeinfo)
      this.axios({
        method: 'post',
        url: 'http://localhost:8081/stuchange/deleteChangeByStuno',
        data: this.$qs.stringify({
          stuno: changeinfo.stuno
        }),
        headers: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
        .then((res) => {
          this.dialogFormVisible = false
          this.opensuccess('删除成功，请查看删除后结果')
          console.log(res.data)
          if (res.data) {
            this.updateinfo()
            //this.getdata('operatelog', 'OperateLogAll')
          } else {
            // alert('更新失败')
            this.openfail('返回值为空，请查看控制台')
            console.log(res.data)
          }
        })
        .catch((err) => {
          this.openfail(err.response)
        })
    },
    //提交流动信息内容
    submitFormchange(changeform) {
      console.log(changeform)
      if (this.xv) {
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/stuchange/changeinfo',
          data: this.$qs.stringify({
            stuno: changeform.stuno,
            type: changeform.type,
            depiction: changeform.depiction,
            time: changeform.time
          }),
          headers: {
            'Content-type': 'application/x-www-form-urlencoded'
          }
        })
          .then((res) => {
            this.opensuccess('修改成功，请查看修改结果')
            this.dialogFormVisible = false
            console.log(res.data)
            if (res.data) {
              this.dialogFormVisible03 = false
              this.updateinfo()
            } else {
              alert('更新失败')
            }
          })
          .catch((err) => {
            this.openfail(err.response)
          })
      } else {
        this.insertChangeinfo()
      }
    },
    //编辑学生基本信息操作
    EditStuClick(stuinfo) {
      console.log(stuinfo)
      this.dialogFormVisible = true
      this.restStuForm()
      this.StuForm.stuno = stuinfo.stuno
      this.StuForm.name = stuinfo.name
      this.StuForm.sex = stuinfo.sex
      this.StuForm.age = stuinfo.age
      this.StuForm.nativePlace = stuinfo.nativePlace
      this.StuForm.address = stuinfo.address
      this.StuForm.classes = stuinfo.classes
      this.StuForm.major = stuinfo.major
      this.StuForm.college = stuinfo.college
      this.StuForm.dormNum = stuinfo.dormNum
      this.StuForm.lengthOfSchooling = stuinfo.lengthOfSchooling
      this.StuForm.yearOfAdmission = stuinfo.yearOfAdmission
      this.StuForm.statusOfStudent = stuinfo.statusOfStudent
    },
    DeleteStuClick(stuinfo) {
      console.log(stuinfo)
      this.axios({
        method: 'post',
        url: 'http://localhost:8081/stuinfo/deleteStuByStuno',
        data: this.$qs.stringify({
          stuno: stuinfo.stuno
        }),
        headers: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
        .then((res) => {
          this.dialogFormVisible = false
          this.opensuccess('删除成功，请查看删除后结果')
          console.log(res.data)
          if (res.data) {
            this.updateinfo()
            //this.getdata('operatelog', 'OperateLogAll')
          } else {
            alert('更新失败')
          }
        })
        .catch((err) => {
          this.openfail(err.response)
        })
    },

    submitFormstu(stuform) {
      console.log(stuform)
      this.axios({
        method: 'post',
        url: 'http://localhost:8081/stuinfo/changestu',
        data: this.$qs.stringify({
          stuno: stuform.stuno,
          name: stuform.name,
          age: stuform.age,
          nativePlace: stuform.nativePlace,
          address: stuform.address,
          classes: stuform.classes,
          dormNum: stuform.dormNum,
          statusOfStudent: stuform.statusOfStudent
        }),
        headers: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
        .then((res) => {
          this.opensuccess('修改成功，请查看修改结果')
          this.dialogFormVisible = false
          console.log(res.data)
          if (res.data) {
            this.updateinfo()
          } else {
            alert('更新失败')
          }
        })
        .catch((err) => {
          this.openfail(err.response)
        })
    },
    updatestuinfo() {
      this.getdata('stuinfo', 'stuinfoall')
      this.getdata('dorm', 'dromNumAll')
      this.getdata('service', 'ServiceAll')
      this.getdata('class', 'ClassAll')
    },
    resetForm(formName) {
      //重置功能有bug，第二个重置对象会重置为第一个的数值
      //演示时只调用一次
      console.log(this.$refs[formName])
      this.$refs[formName].resetFields()
    },
    //重置StuForm对象
    restStuForm() {
      this.StuForm.stuno = ''
      this.StuForm.name = ''
      this.StuForm.sex = ''
      this.StuForm.age = 0
      this.StuForm.nativePlace = ''
      this.StuForm.address = ''
      this.StuForm.classes = ''
      this.StuForm.major = ''
      this.StuForm.college = ''
      this.StuForm.dromNum = ''
      this.StuForm.lengthOfSchooling = ''
      this.StuForm.yearOfAdmission = ''
      this.StuForm.statusOfStudent = ''
    },
    restRePuForm() {
      this.StuRePuForm.id = 0
      this.StuRePuForm.stuno = ''
      this.StuRePuForm.type = ''
      this.StuRePuForm.depiction = ''
      this.StuRePuForm.time = ''
    },
    //重置StuChangeForm对象
    restChangeForm() {
      this.StuChangeForm.stuno = ''
      this.StuChangeForm.type = ''
      this.StuChangeForm.depiction = ''
      this.StuChangeForm.time = ''
    },
    //高级搜索表单操作
    //closeDrawer绑定的是这个函数，与handleClose相同
    handleClose(done) {
      if (this.loading) {
        return
      }
      //
      console.log(this.classw)
      console.log('-------------')
      this.HighSearchFrom.college = this.classw[0]
      this.HighSearchFrom.major = this.classw[1]
      this.HighSearchFrom.classes = this.classw[2]
      console.log(this.HighSearchFrom)
      this.$confirm('确定要提交表单吗？(不选任何条件则显示全部数据)').then((_) => {
        this.axios({
          method: 'post',
          url: 'http://localhost:8081/stuinfo/getStuBySelect',
          data: this.$qs.stringify({
            name: this.HighSearchFrom.name,
            college: this.HighSearchFrom.college,
            classes: this.HighSearchFrom.classes,
            dormNum: this.HighSearchFrom.DormNum,
            major: this.HighSearchFrom.major
          }),
          headers: {
            'Content-type': 'application/x-www-form-urlencoded'
          }
        })
          .then((res) => {
            this.dialogFormVisible = false
            this.HighSearchFrom.college = ''
            this.HighSearchFrom.major = ''
            this.HighSearchFrom.classes = ''
            this.HighSearchFrom.name = ''
            this.HighSearchFrom.DormNum = ''
            console.log(res.data)
            if (res.data) {
              this.opensuccess('查询成功，请查看查询结果')
              this.stuinfoall = []
              res.data.forEach((el) => {
                this.stuinfoall.push(el)
              })
            } else {
              // this.openfail('查询结果为空，请输入正确查询日傲剑')
            }
          })
          .catch((err) => {
            this.openfail(err.response)
          })

        this.loading = true
        this.timer = setTimeout(() => {
          done()

          // 动画关闭需要一定的时间
          setTimeout(() => {
            this.loading = false
          }, 200)
        }, 200)
      })
    },
    cancelForm() {
      this.loading = false
      this.dialog = false
      clearTimeout(this.timer)
    },
    opensuccess(msg) {
      this.$notify({
        title: '成功',
        message: msg,
        type: 'success'
      })
    },
    openfail(msg) {
      this.$notify.error({
        title: '失败',
        message: msg
      })
    },
    //名字排序 数字、字母、中文混合排序问题
    sortDevName(str1, str2) {
      let res = 0
      str1[this.proptype] = String(str1[this.proptype])
      str2[this.proptype] = String(str2[this.proptype])
      if (str1[this.proptype] !== '' && str2[this.proptype] === '') {
        return -1
      } else if (str2[this.proptype] !== '' && str1[this.proptype] === '') {
        return 1
      } else {
        for (let i = 0; ; i++) {
          if (!str1[this.proptype][i] || !str2[this.proptype][i]) {
            res = str1[this.proptype].length - str2[this.proptype].length
            break
          }
          const char1 = str1[this.proptype][i]
          const char1Type = this.getChartType(char1)
          const char2 = str2[this.proptype][i]
          const char2Type = this.getChartType(char2)
          // 类型相同的逐个比较字符
          if (char1Type[0] === char2Type[0]) {
            if (char1 === char2) {
              continue
            } else {
              if (char1Type[0] === 'zh') {
                res = char1.localeCompare(char2)
              } else if (char1Type[0] === 'en') {
                res = char1.charCodeAt(0) - char2.charCodeAt(0)
              } else {
                res = char1 - char2
              }
              break
            }
          } else {
            // 类型不同的，直接用返回的数字相减
            res = char1Type[1] - char2Type[1]
            break
          }
        }
      }
      res = this.order * res
      return res
    },
    getChartType(char) {
      // 数字可按照排序的要求进行自定义，我这边产品的要求是
      // 数字（0->9）->大写字母（A->Z）->小写字母（a->z）->中文拼音（a->z）
      if (/^[\u4e00-\u9fa5]$/.test(char)) {
        return ['zh', 300]
      }
      if (/^[a-zA-Z]$/.test(char)) {
        return ['en', 200]
      }
      if (/^[0-9]$/.test(char)) {
        return ['number', 100]
      }
      return ['others', 999]
    },
    //中文按照字母顺序排序
    sortName(a, b) {
      return a.name.localeCompare(b.name)
    },
    //表格导出
    // exportExcel() {
    //   require.ensure([], () => {
    //     // const { export_json_to_excel } = require('../util/Export2Excel') //此处把路径要写对
    //     const tHeader = ['学号', '姓名', '性别'] //改
    //     // 上面设置Excel的表格第一行的标题
    //     const filterVal = ['stuno', 'name', 'sex'] //改
    //     // 上面的index、nickName、name是tableData里对象的属性
    //     const list = this.stuinfoall //把data里的tableData存到list//改
    //     const data = this.formatJson(filterVal, list)
    //     export_json_to_excel(tHeader, data, '列表excel') //"列表excel"  是下载后的表名 可修改
    //   })
    // },
    // formatJson(filterVal, jsonData) {
    //   return jsonData.map((v) => {
    //     v['date'] = parseTime(v['date']) //调用自己封装的方法进行将毫秒转为时间(如果是从后端拿值且后端返回的是毫秒数，用此方法)
    //     return filterVal.map((j) => v[j])
    //   })
    // }

    exportExcelByTable(id) {
      //var xlsxParam = { raw: true } //转换成excel时，使用原始的格式
      // var wb = XLSX.utils.table_to_book(document.querySelector('#stuinfo'), xlsxParam)
      /* generate workbook object from table */
      // 判断要导出的节点中是否有fixed的表格，如果有，转换excel时先将该dom移除，然后append回去，
      var fix = document.querySelector('.el-table__fixed')
      var wb
      if (fix) {
        wb = XLSX.utils.table_to_book(document.querySelector(id).removeChild(fix))
        document.querySelector(id).appendChild(fix)
      } else {
        wb = XLSX.utils.table_to_book(document.querySelector(id))
      }
      /* get binary string as output */
      var wbout = XLSX.write(wb, {
        bookType: 'xlsx',
        bookSST: true,
        type: 'array'
      })
      try {
        FileSaver.saveAs(new Blob([wbout], { type: 'application/octet-stream;charset=utf-8' }), 'sheetjs.xlsx')
      } catch (e) {
        if (typeof console !== 'undefined') console.log(e, wbout)
      }
      return wbout
    },
    //json对象转换为excel
    exportExcelByJson(name) {
      // 把json转为worksheet对象
      let ws = XLSX.utils.json_to_sheet(this[name]) //这里很神奇啊，我这里导入的是对象数组，他成了，我把对象数组转化成json就报错了
      // 创建workbook对象
      let wb = XLSX.utils.book_new()
      // 添加worksheet 到 workbook
      XLSX.utils.book_append_sheet(wb, ws, 'sheet')
      // 写出 arraybuffer 数据
      let wb_out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
      // 构建Blob对象
      let _blob = new Blob([wb_out], { type: 'application/octet-stream' })
      //下载
      FileSaver(_blob, name + '.xlsx')
      this.opensuccess('已成功导出' + name + '.xlsx文件，请在下载中查看')
    },
    exportTxtByStr(name) {
      //var data = '要导出的内容'
      var Str = JSON.stringify(this[name]) //对象数组转字符串
      //修正导出数据，如果有需求，可以修正为可导入的txt文件格式
      Str = Str.replace('[', '').replace(/{/g, '\n').replace(']', '').replace(/}/g, '')
      //console.log(Str)
      let str = new Blob([Str], { type: 'text/plain;charset=utf-8' })
      // 注意：这里要手动写上文件的后缀名
      saveAs(str, name + `.txt`)
      this.opensuccess('已成功导出' + name + '.txt文件，请在下载中查看')
    },
    //导出文件入口函数，与点击事件相连
    exportFile(name) {
      this.dialogFormVisible02 = false
      console.log(typeof this.exportType)
      // console.log(this.exportType)
      // console.log(this[name])
      if (this.exportType == '') {
        this.openfail('请选择导出方式！')
      } else if (this.exportType === 'excel') {
        this.exportType = ''
        // console.log('excel')
        this.exportExcelByJson(name)
      } else if (this.exportType === 'txt') {
        this.exportType = ''
        // console.log('txt')
        this.exportTxtByStr(name)
      }
    },
    DealWith(serviceinfo, status) {
      this.axios({
        method: 'post',
        url: 'http://localhost:8081/service/dealwith',
        data: this.$qs.stringify({
          id: serviceinfo.id,
          status
        }),
        headers: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
        .then((res) => {
          this.opensuccess('已更新处理，请查看结果')
          this.dialogFormVisible = false
          console.log(res.data)
          if (res.data) {
            this.updateinfo()
          } else {
            alert('更新失败')
          }
        })
        .catch((err) => {
          this.openfail(err.response)
        })
    },
    UnDeal() {
      let i = 0
      //这里由于是在个表单生成的过程，所以多次执行
      //console.log(this.ServiceAll)
      //console.log('------')
      for (let j = 0; j < this.ServiceAll.length; j++) {
        if (this.ServiceAll[j].status == 1) {
          //console.log(this.ServiceAll[j].status)
          i++
        }
      }
      return i
    },
    getPdf() {
      htmlToPdf.getPdf('报表下载')
    },
    //报表更新代码
    Updateechart() {
      this.updateinfo()
      this.updatechart04()
      this.updatechart03()
      this.updatechart01()
    },
    updatechart04() {
      //console.log(this.ServiceAll)
      for (let i = 0; i < this.ServiceAll.length; i++) {
        //console.log(this.ServiceAll[i].status)
        if (this.ServiceAll[i].status == 0) {
          this.echartsdealform.finish += 1
        } else if (this.ServiceAll[i].status == 1) {
          this.echartsdealform.wait += 1
        } else if (this.ServiceAll[i].status == 2) {
          this.echartsdealform.reject += 1
        }
      }
      //console.log(this.chartoption04.series[0].data)
      this.chartoption04.series[0].data[0].value = this.echartsdealform.wait
      this.chartoption04.series[0].data[1].value = this.echartsdealform.finish
      this.chartoption04.series[0].data[2].value = this.echartsdealform.reject
      //console.log(this.chartoption04.series[0].data)
      this.drawChart('main4', this.chartoption04, 240, 550)
    },
    updatechart03() {
      let data = []
      let data2022R = 0
      let data2023R = 0
      let data2022P = 0
      let data2023P = 0
      for (let i = 0; i < this.RePuAll.length; i++) {
        data = this.RePuAll[i].time.split('-')
        console.log(data)
        if (this.RePuAll[i].type == '奖励') {
          if (data[0] === '2022') {
            data2022R += 1
          } else if (data[0] === '2023') {
            data2023R += 1
          }
        } else if (this.RePuAll[i].type == '惩罚') {
          if (data[0] === '2022') {
            data2022P += 1
          } else if (data[0] === '2023') {
            data2023P += 1
          }
        }
      }
      this.echartsrepuform.Re.push(data2022R)
      this.echartsrepuform.Pu.push(data2022P)
      this.echartsrepuform.Re.push(data2023R)
      this.echartsrepuform.Pu.push(data2023P)
      //console.log(data2022R)

      this.chartoption03.series[0].data = this.echartsrepuform.Re
      this.chartoption03.series[1].data = this.echartsrepuform.Pu
      //console.log(this.chartoption03.series[1].data)
      this.drawChart('main3', this.chartoption03, 240, 550)
    },
    Stugroup() {
      let data = []
      let laststu = 0
      let nowstu = 0
      for (let i = 0; i < this.stuinfoall.length; i++) {
        data = this.stuinfoall[i].yearOfAdmission.split('-')
        //console.log(data)
        if (data[0] === '2022') {
          laststu += 1
        } else if (data[0] === '2023') {
          nowstu += 1
        }
      }
      return nowstu - laststu
    },
    Stusex() {
      let boy = 0
      let girl = 0
      for (let item of this.stuinfoall) {
        if (item.sex === '男') {
          boy += 1
        } else if (item.sex === '女') {
          girl += 1
        }
      }
      return boy + '/' + girl
    },
    updatechart01() {
      let hashtable01 = {}
      let hashtable02 = {}
      let hashtable03 = {}
      for (let item of this.stuinfoall) {
        if (hashtable01[item.college]) {
          hashtable01[item.college].push(item)
        } else {
          hashtable01[item.college] = [item]
        }
        if (hashtable02[item.major]) {
          hashtable02[item.major].push(item)
        } else {
          hashtable02[item.major] = [item]
        }
        if (hashtable03[item.classes]) {
          hashtable03[item.classes].push(item)
        } else {
          hashtable03[item.classes] = [item]
        }
      }
      console.log(hashtable01)

      // console.log((hashtable03['地信22003'].length ??= 0))

      console.log(hashtable02)
      console.log(hashtable03)
      console.log(hashtable01['地球科学学院'])
      this.echartsstuform.children[0].value = hashtable01['地球科学学院'].length

      this.echartsstuform.children[0].children[0].value = hashtable02['地信'].length
      this.echartsstuform.children[0].children[0].children[0].value = hashtable03['地信22001'].length
      this.echartsstuform.children[0].children[0].children[1].value = hashtable03['地信22002'].length
      this.echartsstuform.children[0].children[0].children[2].value = hashtable03['地信22003'].length
      this.echartsstuform.children[0].children[0].children[3].value = hashtable03['地信22004'].length
      this.echartsstuform.children[0].children[1].value = hashtable02['地质'].length
      this.echartsstuform.children[0].children[1].children[0].value = hashtable03['地质22001'].length
      this.echartsstuform.children[0].children[1].children[1].value = hashtable03['地质22002'].length
      this.echartsstuform.children[0].children[1].children[2].value = hashtable03['地质22003'].length
      this.echartsstuform.children[0].children[1].children[3].value = hashtable03['地质22004'].length
      // this.echartsstuform.children[0].children[2].value = hashtable02['地产'].length
      // this.echartsstuform.children[0].children[2].children[0].value = hashtable03['地产22001'].length
      this.echartsstuform.children[1].value = hashtable01['地球物理学院'].length
      this.echartsstuform.children[1].children[0].value = hashtable02['地物'].length
      this.echartsstuform.children[1].children[0].children[0].value = hashtable03['地物22001'].length
      this.echartsstuform.children[1].children[0].children[1].value = hashtable03['地物22002'].length
      this.echartsstuform.children[1].children[0].children[2].value = hashtable03['地物22003'].length
      this.echartsstuform.children[1].children[0].children[3].value = hashtable03['地物22004'].length
      this.echartsstuform.children[1].children[1].value = hashtable02['大数据'].length
      this.echartsstuform.children[1].children[1].children[0].value = hashtable03['大数据22001'].length
      this.echartsstuform.children[1].children[1].children[1].value = hashtable03['大数据22002'].length
      this.echartsstuform.children[1].children[1].children[2].value = hashtable03['大数据22003'].length
      this.echartsstuform.children[1].children[1].children[3].value = hashtable03['大数据22004'].length
      this.echartsstuform.children[2].value = hashtable01['艺术与传媒学院'].length
      this.echartsstuform.children[2].children[0].value = hashtable02['艺传'].length
      this.echartsstuform.children[2].children[0].children[0].value = hashtable03['艺传22001'].length
      this.echartsstuform.children[2].children[0].children[1].value = hashtable03['艺传22002'].length
      this.echartsstuform.children[2].children[0].children[2].value = hashtable03['艺传22003'].length
      this.echartsstuform.children[2].children[0].children[3].value = hashtable03['艺传22004'].length
      this.echartsstuform.children[2].children[1].value = hashtable02['美妆'].length
      this.echartsstuform.children[2].children[1].children[0].value = hashtable03['美妆21901'].length
      console.log(this.echartsstuform)
      this.chartoption01.series.data[0] = this.echartsstuform
      this.drawChart('main', this.chartoption01, 550, 350)
    },
    Login() {
      this.dialogFormVisible05 = true
      this.updateinfo()
      //console.log(888)
    },
    Loginclick() {
      this.dialogFormVisible05 = false
      this.Loginform.name = this.user.name
    },
    Leave() {
      this.Loginform.name = '游客(请登录)'
      this.Loginform.stuno = null
      this.Loginform.password = null
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-row {
  margin-bottom: 20px;
}
.el-row :last-child {
  margin-bottom: 0;
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
.el-header {
  background-color: #b3c0d1;
  color: #333;
  line-height: 60px;
}

.fontbig {
  font-size: 30px;
  font-weight: 1000;
}
.fontme {
  font-size: 15px;
  font-weight: 1000;
}
#changeposition {
  margin-top: 15px;
  line-height: 34px !important;
  float: left;
}
.size {
  height: 120px !important;
}
.text {
  font-size: 14px;
  text-align: left;
}

.item1 {
  padding: 18px 0;
  margin-left: 10%;
}

.box-card {
  width: 550px;
}
#pdfDom {
  width: 100%;
  height: 680px;
  overflow-y: auto;
}
</style>

