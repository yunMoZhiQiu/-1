import Vue from 'vue';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue';
// import VueRouter from 'vue-router'
// import router from './router'
// Vue.use(VueRouter)
// Vue.use(router)
import axios from 'axios'
import VueAxios from 'vue-axios'
//全局引入echarts
import * as echarts from "echarts";
Vue.prototype.$echarts = echarts;
import * as xlsx from "xlsx"
Vue.prototype.$xlsx = xlsx
//将html转化为pdf
import htmlToPdf from './components/utils/htmlToPDF'
Vue.use(htmlToPdf)

//引入qs模块
//处理axios.post请求参数为null
import qs from 'qs'
Vue.prototype.$qs = qs
Vue.use(VueAxios, axios);
Vue.use(ElementUI);

Vue.config.productionTip = false
new Vue({

  el: '#app',
  render: h => h(App),
  // router

});