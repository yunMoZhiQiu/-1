INSERT INTO [Service] ([id], [stuno], [describe], [time], [status]) VALUES (1, '202001311', '寝室号变更为9-404', '2022-12-11 00:00:00.000', 0); GO
INSERT INTO [Service] ([id], [stuno], [describe], [time], [status]) VALUES (2, '202001322', '家庭住址变更', '2022-03-12 00:00:00.000', 0); GO
INSERT INTO [Service] ([id], [stuno], [describe], [time], [status]) VALUES (3, '202001349', '在今年3月获得奖励未登录', '2022-05-23 00:00:00.000', 1); GO
INSERT INTO [Service] ([id], [stuno], [describe], [time], [status]) VALUES (4, '200011444', '上学去了', '2022-02-11 00:00:00.000', 2); GO
