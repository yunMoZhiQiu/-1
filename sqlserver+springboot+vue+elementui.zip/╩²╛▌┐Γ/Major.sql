INSERT INTO [Major] ([Major], [Class]) VALUES ('地产            ', '产业22001           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('大数据              ', '大数据22001         '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('大数据              ', '大数据22002         '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('大数据              ', '大数据22003       '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('大数据              ', '大数据22004         '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地物                ', '地物22001           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地物                ', '地物22001（卓越）   '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地物                ', '地物22002   '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地物                ', '地物22003  '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地物                ', '地物22004   '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地信                ', '地信22001           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地信', '地信22002'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地信', '地信22003'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地信', '地信22004'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地质                ', '地质22001           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地质', '地质22002'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地质', '地质22003'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('地质', '地质22004'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('美妆                ', '美妆21901           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('人工智能            ', '人智21902           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('软科                ', '软科22201           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('新媒体              ', '新媒22111           '); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('艺传', '艺传22001'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('艺传', '艺传22002'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('艺传', '艺传22003'); GO
INSERT INTO [Major] ([Major], [Class]) VALUES ('艺传', '艺传22004'); GO
