INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (2, '202001311', '惩罚', '计算机设计大赛一等奖奖200元23', '2022-10-11 00:00:00.000'); GO
INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (4, '202001311', '惩罚', '计算机设计大赛一等奖奖200元2', '2022-10-11 00:00:00.000'); GO
INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (7, '202001354', '奖励', '少时诵诗书所', '2023-03-02 00:00:00.000'); GO
INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (8, '202001354', '奖励', '太傻逼了', '2023-03-02 00:00:00.000'); GO
INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (9, '202001311', '奖励', '计算机设计大赛一等奖奖200元23', '2022-10-11 00:00:00.000'); GO
INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (10, '202001311', '奖励', '计算机设计大赛一等奖奖200元2', '2022-10-11 00:00:00.000'); GO
INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (11, '202001354', '奖励', '少时诵诗书所', '2023-03-02 00:00:00.000'); GO
INSERT INTO [RePu] ([ID], [stuno], [Type], [Depiction], [Time]) VALUES (12, '202001354', '惩罚', '课设没做完', '2023-03-02 00:00:00.000'); GO
