INSERT INTO [Users] ([name], [password], [ID]) VALUES ('wangsssss', 'sdwedqwe', 0); GO
INSERT INTO [Users] ([name], [password], [ID]) VALUES ('wangwu', '666', 1); GO
INSERT INTO [Users] ([name], [password], [ID]) VALUES ('zhangsan', 'yyy', 2); GO
INSERT INTO [Users] ([name], [password], [ID]) VALUES ('是否多个', 'eee', 4); GO
INSERT INTO [Users] ([name], [password], [ID]) VALUES ('云米哦', '222级级级级j', 10); GO
