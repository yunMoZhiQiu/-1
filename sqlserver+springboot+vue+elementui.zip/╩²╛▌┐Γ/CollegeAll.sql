INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地产', '产业22001           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '大数据', '大数据22001         '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '大数据', '大数据22002         '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '大数据', '大数据22003       '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '大数据', '大数据22004         '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '地物', '地物22001           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '地物', '地物22001（卓越）   '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '地物', '地物22002   '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '地物', '地物22003  '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球物理学院', '地物', '地物22004   '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地信', '地信22001           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地信', '地信22002'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地信', '地信22003'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地信', '地信22004'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地质', '地质22001           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地质', '地质22002'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地质', '地质22003'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('地球科学学院', '地质', '地质22004'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('艺术与传媒学院', '美妆', '美妆21901           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('计算机科学与技术', '人工智能', '人智21902           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('计算机科学与技术', '软科', '软科22201           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('艺术与传媒学院', '新媒体', '新媒22111           '); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('艺术与传媒学院', '艺传', '艺传22001'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('艺术与传媒学院', '艺传', '艺传22002'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('艺术与传媒学院', '艺传', '艺传22003'); GO
INSERT INTO [CollegeAll] ([College], [Major], [Class]) VALUES ('艺术与传媒学院', '艺传', '艺传22004'); GO
