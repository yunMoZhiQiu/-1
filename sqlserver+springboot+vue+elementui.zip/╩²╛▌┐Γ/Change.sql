INSERT INTO [Change] ([stuno], [Type], [Depiction], [Time]) VALUES ('202001311', '转专业', '2022年因数据库课设未完成被勒令退学44', '2022-10-11 00:00:00.000'); GO
INSERT INTO [Change] ([stuno], [Type], [Depiction], [Time]) VALUES ('202001322', '毕业', '2022年完成学业安排被授予毕业', '2022-06-22 00:00:00.000'); GO
INSERT INTO [Change] ([stuno], [Type], [Depiction], [Time]) VALUES ('202001354', '转专业', '嗯嗯嗯', '2023-03-05 00:00:00.000'); GO
INSERT INTO [Change] ([stuno], [Type], [Depiction], [Time]) VALUES ('202001365', '转专业', '2023年从地信22001转到软科22201', '2023-03-10 00:00:00.000'); GO
