package com.example.shujukushangji;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.shujukushangji.entity.User;
import com.example.shujukushangji.mapper.UserMapper;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//控制器,写接口
@RestController
@RequestMapping("/user")
public class controller {
    @Autowired
    UserMapper mapper;

    @GetMapping
    public List<User> getUsers() {
        return mapper.selectList(null);
    }

    @PostMapping
    public Boolean saveUser(@RequestBody String Suser) {
        //有bug，传过来的参数中ID为空
//        System.out.println(user);
//        JSONObject Jsonuser = JSON.parseObject(Suser);
//        int id = Integer.parseInt(Jsonuser.get("ID").toString());
//        User user = new User(id, Jsonuser.get("name").toString(), Jsonuser.get("password").toString());
//        System.out.println(id);
//        user.setID(10);
//        System.out.println(user.getID());
//        System.out.println(user.getName());
//        System.out.println(user.getPassword());
//        int i = mapper.insert(user);
        return true;
    }

    @PutMapping
    public Boolean updateUser(@RequestBody String Suser) {
//        JSONObject Jsonuser = JSON.parseObject(Suser);
//        int id = Integer.parseInt(Jsonuser.get("ID").toString());
//        User user = new User(id, Jsonuser.get("name").toString(), Jsonuser.get("password").toString());
//        System.out.println(id);
//        int i = mapper.updateById(user);
        return true;
    }

    @DeleteMapping
    public Boolean deleteUser(Integer id) {
//        int i = mapper.deleteById(id);
        return true;
    }

}
