package com.example.shujukushangji.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//对应数据库的表
@AllArgsConstructor //生成全参构造器
@NoArgsConstructor//生成无参构造器
@Data //数据lombok,可以帮助自动生成对应的属性
@TableName("dbo.Users")//设置对应数据库里的那张表
public class User {
//    @TableId(value = "ID",type = IdType.INPUT) //这种方式是主键手动输入

    private int ID;
    private String name;
    private String password;
}
