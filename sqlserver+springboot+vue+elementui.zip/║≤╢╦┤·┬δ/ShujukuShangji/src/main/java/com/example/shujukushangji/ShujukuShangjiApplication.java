package com.example.shujukushangji;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@MapperScan("com.example.shujukushangji.mapper")//扫描mapper的位置
@SpringBootApplication
public class ShujukuShangjiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShujukuShangjiApplication.class, args);
    }

}
