package com.example.shujukushangji;

import com.example.shujukushangji.entity.User;
import com.example.shujukushangji.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class ShujukuShangjiApplicationTests {
    @Autowired
    UserMapper userMapper;


    @Test
    void contextLoads() {
//        查
        List<User> users=userMapper.selectList(null);
        users.forEach(System.out::println);
//        System.out.println(users.get(0).getUser()+users.get(0).getPassword());
//        System.out.println(users.get(1).getUser()+users.get(1).getPassword());

//        更新
//        User zhangsan=new User(1,"wangwu","666");
//        int update = userMapper.updateById(zhangsan);//该方法根据id修改内容，可以修改id对象，一般自带uodate修改所有数据
//        System.out.println(update);

//        插入
//        User user=new User();
//        user.setID(3);
//        user.setName("未获");
//        user.setPassword("sdjaoihjwaeoid");
//        int insert = userMapper.insert(user);
//        System.out.println(insert);

        //删除
        userMapper.deleteById(3);
    }

}
